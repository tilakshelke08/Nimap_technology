



















package swaglabs;

import org.openqa.selenium.By;

 import org.oponga.selentum.Neboriver; 
 import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.edge.EdgeDriver;

import java.util. Iterator;
import java.util.Set;

public class Dwaglabs_Project { 
  public static void main(String[] args) throws

InterruptedException { System.setProperty("WebDriver.com.driver", "C:\\browser\\chronedriver.exe");
 WebDriver driver= new ChromeDriver();

driver.get("https://testffc.nimapinfotech.com/auth/login"); 
driver.findElement(By.id("mat-input-0")).sendKeys("sharemarket0801@gmail.com"); 
driver.findElement(By.id("mat-input-1")). sendKeys("Asdf@12345");

driver.findElement(By.xpath("//*[@id="kt_login_signin_submit"]")).click(); 
System.out.println("Sign in Successful");

Thread.sleep(2000);
 driver.manage(). window() maximize();

driver.findElement(By.xpath("//*[@id=\"Inventory_filter_container\"]/select")).click();

Thread.sleep(2000); 
driver.findElement(By.xpath("//*[@id="kt_login"]/div/div[2]/kt-login/div[1]/a")).click();
Threed.sleep(2000);
driver.findElement(By.id("mat-input-8")).sendKeys("Tilak Shelke "); 
Threed.sleep(2000);

driver.findElement(By.id("mat-input-10")).sendKeys("7776980384"); 

Thread.sleep(2000);
driver.findElement(By.id("mat-input-11")).sendKeys("sharemarket0801@gmail.com "); 

System.out.println("sign up successful"); 
Thread.steep (5000); \
driver.findElement(By.xpath("//*[@id="kt_login_signin_submit"]")).click();


}

}
 





















 




 	 

 	 

 	 

   

 

   

 

 	 











 









































 




 	 

 	 

 	 

   

 

   

 

 	 










